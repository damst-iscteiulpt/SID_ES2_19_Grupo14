package codesmell;

import java.util.ArrayList;

import javax.naming.StringRefAddr;

public class Rules {
	String nome ;
	ArrayList<Metrics> metrics;
	ArrayList<String> submetrics;	
	public  Rules(String nome ,ArrayList<Metrics> metrics ) {
		submetrics= new ArrayList<>();
		for (int i = 0; i < metrics.size(); i++) {
			String[] ts = metrics.get(i).getName().split("/");
			for (int j = 0; j < ts.length; j++) {
				System.out.println(ts[j]);
				submetrics.add(ts[j]);
			}
			
		}
		this.nome=nome;
		this.metrics=metrics;		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public ArrayList<String> getsubmetricks() {
		return submetrics;
		
	}
	public ArrayList<Metrics> getMetrics() {
		return metrics;
	}

	public void setMetrics(ArrayList<Metrics> metrics) {
		this.metrics = metrics;
	}

	public boolean smell(String first ,String s) {
		for (int i = 0; i < metrics.size(); i++) {
			if(metrics.get(i).verefy(first,s,nome)==true) {
				return true;
			}
		}
		return false;
	}

}
