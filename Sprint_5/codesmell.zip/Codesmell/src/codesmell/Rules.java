package codesmell;

import java.util.ArrayList;

import javax.naming.StringRefAddr;

public class Rules {
	String nome ;
	ArrayList<Metrics> metrics;
	
	public  Rules(String nome ,ArrayList<Metrics> metrics ) {
		this.nome=nome;
		this.metrics=metrics;		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public ArrayList<Metrics> getMetrics() {
		return metrics;
	}

	public void setMetrics(ArrayList<Metrics> metrics) {
		this.metrics = metrics;
	}

	public boolean smell(String first ,String s) {
		for (int i = 0; i < metrics.size(); i++) {
			if(metrics.get(i).verefy(first,s,nome)==true) {
				return true;
			}
		}
		return false;
	}

}
