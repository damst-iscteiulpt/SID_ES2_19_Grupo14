package codesmell;

import java.util.ArrayList;

public class Controler {
	private CVSFile file;
	private ArrayList<Rules> rules;
	
public Controler() {
	rules = new ArrayList<>();
	file = new CVSFile("data-class.csv" , rules);
	Long_Method_rule();
	Feature_Envy_rule();
	God_Class_rule();
	Data_Class_rule();	
	new CSVReader(file);
	new gui.NewGUI(file);

}

private void Long_Method_rule() {
	ArrayList<Metrics> tmp = new ArrayList<>();
	tmp.add(new Metrics("LOC>80/CYCLO>10" ));
	rules.add(new Rules("Long_Method", tmp));
}

private void Feature_Envy_rule() {
	ArrayList<Metrics> tmp = new ArrayList<>();
	tmp.add(new Metrics("ATFD>4/LAA<0.428571" ));
	tmp.add(new Metrics("ATFD>4/LAA>0.428571/NOFA>6 " ));
	rules.add(new Rules("Feature_Envy", tmp));
}

private void God_Class_rule() {
	ArrayList<Metrics> tmp = new ArrayList<>();
	tmp.add(new Metrics("WMCNAMM>47" ));
	tmp.add(new Metrics("WMCNAMM<=47/NOMNAMM>9/RFC>34" ));
	rules.add(new Rules("God_Class", tmp));
}

private void Data_Class_rule() {
	ArrayList<Metrics> tmp = new ArrayList<>();
	tmp.add(new Metrics("NOAM>2/WMCNAMM<21/NIM<=30" ));
	rules.add(new Rules("Data_Class", tmp));
}



}
