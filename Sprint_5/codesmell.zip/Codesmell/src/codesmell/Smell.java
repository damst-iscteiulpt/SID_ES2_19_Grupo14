package codesmell;

public class Smell {

	private int linha;
	private String tipo;
	
	public Smell(String tipo, int linha) {
	this.linha=linha;
			this.tipo=tipo;
	}

	public int getLinha() {
		return linha;
	}

	public void setLinha(int linha) {
		this.linha = linha;
	}

	

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getTipo() {
		return tipo;
		// TODO Auto-generated method stub
	
	}
}
