package codesmell;

import java.awt.FlowLayout;
import java.util.ArrayList;

public class Metrics {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Metrics(String name) {
		this.name = name;
	}

	private int intgetter(String first, String n) {
		String temp = " ";
		if (first.contains(n + "_method")) {
			temp = n + "_method";
		}
		if (first.contains(n + "_method") == false) {
			temp = n + "_type";
		}

		if (temp.equals("NOFA_type") == true) {
			temp = "num_final_attributes";
		}
		if (!first.contains(n)) {
			return -1;
		}
		String[] f = first.split(",");
		for (int i = 0; i < f.length; i++) {
			if (f[i].equals(temp) == true) {
				return i;
			}

		}
		return -1;

	}

	public boolean verefy(String first, String s, String nome) {
		int num = 0;
		String[] fst = first.split(",");
		String[] nmspt = name.split("/");
		
		String[] spt = s.split(",");

		for (int i = 0; i < nmspt.length; i++) {

			if (nmspt[i].contains(">=")) {
				String[] tmp = nmspt[i].split(">=");
				int tst = intgetter(first, tmp[0]);

				if (tst != -1) {

					Float p = (float) Float.parseFloat(tmp[1]);
					Float o = (float) Float.parseFloat(spt[tst]);
					if (o >= p) {
						num++;
					}
				}
				if (tst == -1) {
					return false;
				}

			}
			if (nmspt[i].contains("<=")) {
				String[] tmp = nmspt[i].split("<=");
				int tst = intgetter(first, tmp[0]);
				if (tst != -1 && (spt[tst].contains("?"))==false) {
					String d = fst[tst];
					Float p = (float) Float.parseFloat(tmp[1]);
					Float o = (float) Float.parseFloat(spt[tst]);
					if (o <= p) {
						num++;
					}
				}
				if (tst == -1) {
					return false;
				}

			}
			if (nmspt[i].contains(">") && !nmspt[i].contains("=")) {
				String[] tmp = nmspt[i].split(">", 2);
				int tst = intgetter(first, tmp[0]);
				if (tst != -1) {
					String d = fst[tst];
					Float p = (float) Float.parseFloat(tmp[1]);
				
					Float o = (float) Float.parseFloat(spt[tst]);
					if (o > p) {
						num++;
					}
				}
				if (tst == -1) {
					return false;
				}

			}
			if (nmspt[i].contains("<") && !nmspt[i].contains("=")) {
				String[] tmp = nmspt[i].split("<", 2);
				int tst = intgetter(first, tmp[0]);
				if (tst != -1) {
					Float p = (float) Float.parseFloat(tmp[1]);
					Float o = (float) Float.parseFloat(spt[tst]);
					if (o < p) {
						num++;
					}
				}
				if (tst == -1) {
					return false;
				}

			}

			if (nmspt[i].contains("=") && !nmspt[i].contains("<") && !nmspt[i].contains(">")) {
				String[] tmp = nmspt[i].split("=");
				int tst = intgetter(first, tmp[0]);
				if (tst != -1) {
					String d = fst[tst];
					Float p = (float) Float.parseFloat(tmp[1]);
					Float o = (float) Float.parseFloat(spt[tst]);
					if (p == o) {
						num++;
					}
				}
				if (tst == -1) {
					return false;
				}

			}
			if (num == (nmspt.length  )) {
				System.err.println(name);
				System.out.println(s);
				System.err.println(true +" " + nmspt.length+ "  :" + nome  );
				return true;
			}
		}
		
		return false;
	}
}
