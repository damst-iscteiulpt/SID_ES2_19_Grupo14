package codesmell;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class CSVReader {

	public CSVReader(CVSFile f) {
		try {
		BufferedReader in = new BufferedReader(new FileReader("./Data/csv/data-class.csv"));
	    String line;
	    while ((line=in.readLine()) != null ) {
	    	f.add_to_codesmell(line);
		}
	   
	    in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	}
}
