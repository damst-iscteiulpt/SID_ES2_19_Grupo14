package codesmell;

import java.util.ArrayList;

public class CVSFile {
	private String name;
	private ArrayList<String> codesmell_string;
	private ArrayList<Rules> rules;
	private String first;
	private int select;

	public CVSFile(String name, ArrayList<Rules> rules) {
		this.name = name;
		this.rules = rules;
		codesmell_string = new ArrayList<>();
		select = 1;
	}

	public String getName() {
		return name;
	}

	public void add_to_codesmell(String s) {

		if (select >= 2) {
			codesmell_string.add(s);
			checkmetrics(s);
			select++;
			}
		if (select == 1) {
			first = s;
			select++;
			}
		
	}

	private void checkmetrics(String s) {
		for (int i = 0; i < rules.size(); i++) {
			if(rules.get(i).smell(first,s)==true) {
				
			}
			
		}
	}
}
