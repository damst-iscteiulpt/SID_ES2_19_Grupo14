package codesmell;

import java.util.ArrayList;

public class CVSFile {
	private String name;
	private ArrayList<String> codesmell_string;
	private ArrayList<Rules> rules;
	private ArrayList<Smell> smell;
	private String first;
	private int select;

	public CVSFile(String name, ArrayList<Rules> rules) {
		this.name = name;
		this.rules = rules;
		smell= new ArrayList<>();
		codesmell_string = new ArrayList<>();
		select = 1;
	}

	public String getName() {
		return name;
	}

	public void add_to_codesmell(String s) {

		if (select >= 2) {
			codesmell_string.add(s);
			checkmetrics(s);
			select++;
			}
		if (select == 1) {
			first = s;
			select++;
			}
		
	}

	private void checkmetrics(String s) {
		for (int i = 0; i < rules.size(); i++) {
			if(rules.get(i).smell(first,s)==true) {
				smell.add(new Smell(rules.get(i).nome, select));
			}
			
		}
	}

	public ArrayList<String> getCodesmell_string() {
		return codesmell_string;
	}

	public void setCodesmell_string(ArrayList<String> codesmell_string) {
		this.codesmell_string = codesmell_string;
	}

	public ArrayList<Rules> getRules() {
		return rules;
	}

	public void setRules(ArrayList<Rules> rules) {
		this.rules = rules;
	}

	public ArrayList<Smell> getSmell() {
		return smell;
	}

	public void setSmell(ArrayList<Smell> smell) {
		this.smell = smell;
	}

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public int getSelect() {
		return select;
	}

	public void setSelect(int select) {
		this.select = select;
	}

	public void setName(String name) {
		this.name = name;
	}
}
