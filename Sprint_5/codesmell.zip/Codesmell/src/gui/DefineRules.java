package gui;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Panel;
import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.List;
import java.awt.Button;
import java.awt.Label;
import java.awt.Choice;

public class DefineRules {

	private JPanel contentPane;
	private JFrame frame;

	/**
	 * Create the frame.
	 */
	public DefineRules() {
		this.frame = new JFrame("DefinedRules");
		frame.setDefaultCloseOperation(frame.DISPOSE_ON_CLOSE);
		frame.setBounds(100, 100, 450, 362);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JLabel lblDefineRules = new JLabel("Define Rules");
		lblDefineRules.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(lblDefineRules, BorderLayout.NORTH);

		JButton btnSave = new JButton("Save");
		contentPane.add(btnSave, BorderLayout.SOUTH);

		Panel panel = new Panel();
		contentPane.add(panel, BorderLayout.CENTER);

		JLabel lblCodeSmell = new JLabel("Code Smell");
		panel.add(lblCodeSmell, "2, 2, right, default");

		JComboBox comboBox = new JComboBox();
		panel.add(comboBox, "4, 2, fill, default");

		JLabel lblMetrics = new JLabel("Metrics");
		panel.add(lblMetrics, "2, 4");

		List list = new List();
		panel.add(list, "4, 4");

		Button btnAddMetric = new Button("Add Metric");
		panel.add(btnAddMetric, "4, 6");

		JLabel lblSelectedMetrics = new JLabel("Selected Metrics");
		panel.add(lblSelectedMetrics, "2, 8");

		List list_1 = new List();
		panel.add(list_1, "4, 8");

		Label lblOperator = new Label("Operator");
		panel.add(lblOperator, "2, 10");

		Choice choice = new Choice();
		panel.add(choice, "4, 10");
		frame.setVisible(true);
	}

}
