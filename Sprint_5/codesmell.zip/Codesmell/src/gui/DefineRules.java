package gui;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.text.Document;

import codesmell.CVSFile;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Panel;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.List;
import java.awt.Button;
import java.awt.Label;
import java.awt.Choice;
import java.awt.Dimension;

public class DefineRules {

	private JPanel contentPane;
	private JFrame frame;
	private CVSFile f;

	/**
	 * Create the frame.
	 */
	public DefineRules(CVSFile f) {
		this.f=f;
		this.frame = new JFrame("DefinedRules");
		frame.setDefaultCloseOperation(frame.DISPOSE_ON_CLOSE);
		frame.setBounds(100, 100, 450, 362);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JLabel lblDefineRules = new JLabel("Define Rules");
		lblDefineRules.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(lblDefineRules, BorderLayout.NORTH);

		JButton btnSave = new JButton("Save");
		contentPane.add(btnSave, BorderLayout.SOUTH);

		Panel panel = new Panel();
		contentPane.add(panel, BorderLayout.CENTER);

		JLabel lblCodeSmell = new JLabel("Code Smell");
		panel.add(lblCodeSmell, "2, 2, right, default");

		JComboBox comboBox = new JComboBox();
		for(int i=0 ; i<f.getRules().size();i++) {
			comboBox.addItem(f.getRules().get(i).getNome());		
			}
		panel.add(comboBox, "4, 2, fill, default");

		
		JLabel lblMetrics = new JLabel("Metrics");
		panel.add(lblMetrics, "2, 4");

		List list = new List();
		panel.add(list, "4, 4");

		comboBox.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				list.removeAll();
				 for (int i = 0; i < f.getRules().get(comboBox.getSelectedIndex()).getMetrics().size(); i++) {
				String t = f.getRules().get(comboBox.getSelectedIndex()).getMetrics().get(i).getName().replaceAll("/", " and ");
			
					 list.add(t);
				}
				frame.repaint();
				list.validate();
			}
		});
	

		Button btnAddMetric = new Button("Add Metric");
		panel.add(btnAddMetric, "4, 6");

		JLabel lblSelectedMetrics = new JLabel("Selected Metrics");
		panel.add(lblSelectedMetrics, "2, 8");

		JTextArea list_1 = new JTextArea();
		list_1.setText("////////////////////////////////////////////////////////");
		list_1.setEditable(true);
		panel.add(list_1);

		Label lblOperator = new Label("Operator");
		panel.add(lblOperator, "2, 10");

		Choice choice = new Choice();
		choice.add("and");
		choice.add("or");
		panel.add(choice, "4, 10");
		frame.setVisible(true);
	}

}
