package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.LayoutFocusTraversalPolicy;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import codesmell.CSVReader;
import codesmell.CVSFile;
import codesmell.Smell;

public class NewGUI {

	private JPanel contentPane;
	private JTextArea table;
	private JFrame frame;
	private CVSFile rd;

	/**
	 * Create the frame.
	 * @param rd 
	 */
	public NewGUI(CVSFile rd) {
		this.rd=rd;
		frame = new JFrame("Intro");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 771, 418);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(null);

		Panel appMainPanel = new Panel();
		appMainPanel.setBounds(12, 60, 729, 301);
		contentPane.add(appMainPanel);
		appMainPanel.setLayout(new BorderLayout(0, 0));

		Panel menuPanel = new Panel();
		appMainPanel.add(menuPanel, BorderLayout.NORTH);
		menuPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		Label Menu = new Label("Menu");
		Menu.setAlignment(Label.CENTER);
		Menu.setFont(new Font("Dialog", Font.BOLD, 16));
		menuPanel.add(Menu);

		JButton btnDefineThresholds = new JButton("Define Thresholds");
		menuPanel.add(btnDefineThresholds);
		btnDefineThresholds.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				DefineThresholds newGUI = new DefineThresholds(rd);

			}
		});

		JButton btnDefineRules = new JButton("Define Rules");
		menuPanel.add(btnDefineRules);
		btnDefineRules.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new DefineRules(rd);
			}
		});

		JButton btnNewCodeSmell = new JButton("New Code Smell");
		menuPanel.add(btnNewCodeSmell);

		JButton btnFiles = new JButton("Files");
		menuPanel.add(btnFiles);
		btnFiles.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					new FilesGUI();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		Panel subPanel = new Panel();
		appMainPanel.add(subPanel, BorderLayout.CENTER);
		subPanel.setLayout(new BorderLayout(0, 0));

		JSeparator separator = new JSeparator();
		subPanel.add(separator, BorderLayout.NORTH);

		Label lblResults = new Label("Results");
		lblResults.setFont(new Font("Dialog", Font.BOLD, 12));
		subPanel.add(lblResults, BorderLayout.NORTH);

		table = new JTextArea();
		table.setEditable(true);
		String t = "";
		for(int i = 0 ;i<rd.getSmell().size();i++ ) {
			t=(t+"Tipo de codesmell: "+rd.getSmell().get(i).getTipo() + "   n� de linha:" + rd.getSmell().get(i).getLinha() + "\n");	
		}
		table.setText(t);
		JScrollPane te= new JScrollPane(table);
		subPanel.add(te, BorderLayout.CENTER);

		
		Panel appNamePanel = new Panel();
		appNamePanel.setBackground(Color.BLACK);
		appNamePanel.setBounds(12, 10, 731, 44);
		contentPane.add(appNamePanel);

		JLabel lblGotchaCodeSmell = new JLabel("Gotcha Code Smell");
		appNamePanel.add(lblGotchaCodeSmell);
		lblGotchaCodeSmell.setBackground(Color.BLACK);
		lblGotchaCodeSmell.setFont(new Font("Courier New", Font.BOLD, 28));
		lblGotchaCodeSmell.setForeground(Color.WHITE);
		lblGotchaCodeSmell.setHorizontalAlignment(SwingConstants.CENTER);
		frame.setVisible(true);
	}

	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}

			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}

			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}

}
