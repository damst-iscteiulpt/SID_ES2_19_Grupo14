package gui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import codesmell.CVSFile;

public class DefineThresholds {

	private JPanel contentPane;
	private JTextField textField;
	private JFrame frame;
	private CVSFile file;

	/**
	 * 
	 * Create the frame.
	 */
	public DefineThresholds(CVSFile file) {
		this.file=file;
		frame = new JFrame("DefineThreshold");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setBounds(100, 100, 450, 219);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		Panel panel = new Panel();
		contentPane.add(panel, BorderLayout.CENTER);

		JLabel lblCodeSmellType = new JLabel("Code Smell Type");
		panel.add(lblCodeSmellType, "2, 2, right, default");

		JComboBox<String> comboBox = new JComboBox();
		for(int i=0 ; i<file.getRules().size();i++) {
			comboBox.addItem(file.getRules().get(i).getNome());		
			}
		panel.add(comboBox, "4, 2, fill, default");
		JComboBox comboBox_1 = new JComboBox();
		panel.add(comboBox_1, "4, 4, fill, default");

		comboBox.addItemListener(new ItemListener() {
	
			@Override
			public void itemStateChanged(ItemEvent e) {
				comboBox_1.removeAllItems();
				 for (int i = 0; i < file.getRules().get(comboBox.getSelectedIndex()).getMetrics().size(); i++) {
					 String t = file.getRules().get(comboBox.getSelectedIndex()).getMetrics().get(i).getName().replaceAll("/", " and ");
					 
					comboBox_1.addItem(t);
				}
				frame.repaint();
				comboBox_1.updateUI();
			}
		});
		
		JLabel lblMetric = new JLabel("Metric");
		panel.add(lblMetric, "2, 4, right, default");

		
		JLabel lblThreshold = new JLabel("Threshold");
		panel.add(lblThreshold, "2, 6, right, default");

		textField = new JTextField();
		panel.add(textField, "4, 6, fill, default");
		textField.setColumns(10);

		Label lblDefineThresholds = new Label("Define Thresholds");
		lblDefineThresholds.setFont(new Font("Dialog", Font.BOLD, 20));
		contentPane.add(lblDefineThresholds, BorderLayout.NORTH);

		Button btnSave = new Button("Save");
		contentPane.add(btnSave, BorderLayout.SOUTH);
		btnSave.setForeground(Color.WHITE);
		btnSave.setBackground(Color.BLACK);
		frame.setVisible(true);
	}

}
